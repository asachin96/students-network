#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>
#define size 15
/*validate- takes an infix expr and validates by checking following conditions:-
	skip all "(" and ")" coz it's being validated during convertion
	1- check for double digit operands
	2- check for operator after operator*/

int validate(char infix[]){
	int flag=-1,i=0,length;		/*flag to check whether prev char is opd or opt? and it is 1 if operand and 0 if operator(initially be -1)*/
	length=strlen(infix);
 	if(length%2==0||length==1)
		return(0);
	while(infix[i]!='\0'){
		if(infix[i]=='('||infix[i]==')'){	//skipping "(" and ")"
			i++;
			continue;
		}
		if(isalnum(infix[i])){
			if(flag==1)	// check condt 1
				return(0);
			else flag=1; //it's an operand so...
		}else{//  operator
			if(flag==0) 
				return(0);	//check condt 2
			else 
				flag=0; // it's an operator so...
		}
		i++;	//you forget this,you will shit yourself :D
	}
	return(1);
}
int prcd(char ch){
	switch(ch){
	case '+':return(1);
	case '-':return(1);
	case '/':return(2);
	case '*':return(2);
	default :printf("Invalid operator used\n");
		 exit(0);	
	}
}
/*convert- it's obviuos wat it does, but how?
	1:if operand add it postfix expr simply like that..
	else
	2:if "(" put it in stack(operator) and continue loop
	3:if ")" pop everything in stack and push it to postfix expr till "(" in stk.
	4:if operator-compare prcd of operator on top of stack and the one u have in infix expr, now	
		i)if the one in stack has greater or equal prcd pop it and push it to postfix expr and push the one in infix to stack..
		else just push it to stack
	all this in one loop
	after that in another loop pop all in stack and push to postfix expr check if you get an "(",if you do it's an invlaid expr..	*/

convert(char infix[]){
	int i=0,j=0,top=-1;
	char postfix[size],stack[size];
	while(infix[i]!='\0'){
		if(isalnum(infix[i]))
			postfix[j++]=infix[i++];		
		else{
			if(infix[i]=='('){			
				stack[++top]=infix[i++];
				continue;
			}else if(infix[i]==')'){
				while(stack[top]!='('){
					if(top==0||top==-1){
						printf("invalid\n");
						return;
					}
					postfix[j++]=stack[top--];
				}	// in a sense we found "("..
				top--;	// to ignore "(" at top..
				i++;
				continue;
			}else if(top!=-1&&stack[top]!='('){
				if(prcd(stack[top])>=prcd(infix[i]))
					postfix[j++]=stack[top--];
			}
			stack[++top]=infix[i++];
		} // end else
	}// end while (loop one)
	
	while(top>=0){
		if(stack[top]!='(')
			postfix[j++]=stack[top--];
		else{
			printf("invald pa, y the hell u can't give right expression u dumbass??\n");
			return;
		}
	}
	postfix[j]='\0';
	printf("The postfix expression is %s\n",postfix);
}

main(){
	char infix[size];
	while(1){
		printf("Enter only single digit infix expression\n");
		scanf("%s",infix);
		if(!validate(infix))
			printf("Invalid expression\n");
		else
			convert(infix);
	}
}











