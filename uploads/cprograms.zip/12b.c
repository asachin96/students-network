#include <stdio.h>
#include <stdlib.h>

struct node
{
 int info;
 struct node *left;
 struct node *right;
 int rthread;       
};
typedef struct node* NODEPTR;
NODEPTR root=NULL;
NODEPTR getnode()
{
 NODEPTR temp;
 temp=(NODEPTR)malloc(sizeof(struct node));
 
 if(temp==NULL)
 {
    printf("No Memory Allocation\n");
    exit(0);
 }        
 else
 {
    temp->left=NULL;    
    temp->right=NULL;
    temp->rthread=1;
    return temp;
 }
}

void setleft(NODEPTR p,int x)
{
   NODEPTR q;
   
   if(p==NULL)
              printf("\nVoid Insertion");
   else if(p->left!=NULL)
              printf("\nInvalid Instruction");
   else
   {
       q=getnode();
       q->info=x;
       p->left=q;
       q->left=NULL;
       q->right=p;
   }     
}

void setright(NODEPTR p,int x)
{
   NODEPTR q,r;
   
   if(p==NULL)
              printf("\nVoid Insertion");
   else if(!(p->rthread) && p->right!=NULL)
              printf("\nInvalid Instruction");
   else
   {
       q=getnode();
       q->info=x;
       r=p->right;
       p->right=q;
       q->left=NULL;
       q->right=r;
       q->rthread=1;
       p->rthread=0;
   }     
}

void insert(int x)
{
   NODEPTR temp,p,q;
   temp=getnode();
   if(root==NULL)
   {
     temp->info=x;
     root=temp;
   }
	else
   {
       p=q=root;
       while(q!=NULL)
       {
          p=q;
          if(x<q->info)
             q=p->left;
          else
          {
                       if(!q->rthread)
                       q=p->right;
                       else
                       break;
                       
          }
       }
       
       if(x==p->info)
                     printf("Duplicate element");
       else if(x<p->info)
            setleft(p,x);
       else
            setright (p,x);
   }
     
}

void display()
{
     NODEPTR p,q;
     p=root;
     do{
             q=NULL;
             while(p!=NULL)
             {
                           q=p;
                           p=p->left;
                           
             }
             
             if(q!=NULL)
             {
                        printf("%d ",q->info);
                        p=q->right;
                        
                        while(q->rthread &&p!=NULL)
                        {
                                         printf("%d ",p->info);
                                         q=p;
                                         p=p->right;
                        }           
             }
             

      }while(q!=NULL);
}

int main()
{
     int item;
     printf("Enter elements of BST\n");
     printf("-1 to stop\n");
     do{
        scanf("%d",&item);
        if(item==-1)
        break;        
        insert(item);
     }while(item!=-1);
     if(root==NULL)
     {
        printf("Tree Empty\n");
        exit(0);
     }
     printf("BST is :\n");
     display();
     printf("\n");     
}

