#include<stdio.h>
#include<stdlib.h>
int stack[8],top1=-1,top2=8,choice;
push(){
	int x;
	if(top1==top2-1){
		printf("Stack fUll\n");
		return;
	}
	printf("Enter input\n");
	scanf("%d",&x);
	if(choice==1)
		stack[++top1]=x;
	else
		stack[--top2]=x;
}
pop(){
	if(choice==1){
		if(top1==-1){
			printf("Stack1 Empty\n");
			return;
		}
		printf("The element poped is %d\n",stack[top1--]);
	}else{
		if(top2==8){
			printf("Stack2 Empty\n");
			return;
		}
		printf("The element poped is %d\n",stack[top2++]);
	}
}
display(){
	int i;
	if(choice==1){
		if(top1==-1){
			printf("Stack1 Empty\n");
			return;
		}
		printf("the elements in stack1 are\n");
		for(i=top1;i>=0;i--)
			printf("%d\n",stack[i]);
	}else{
		if(top2==8){
			printf("Stack2 Empty\n");
			return;
		}
		printf("the elements in stack2 are\n");
		for(i=top2;i<=7;i++)
			printf("%d\n",stack[i]);
	}
}		 
main(){
	int op;
	printf("Enter\t1:To access stack1\t2:For stack2\t3:To Exit\n");
	scanf("%d",&choice);
	if(choice==3)	exit(0);
	while(1){
		printf("Enter the operation to perform\n1:Push\t2:pop\t3:display\t4:To exit form stack%d\n",choice);
		scanf("%d",&op);
		switch(op){
			case 1:push();
				break;
			case 2:pop();
				break;
			case 3:display();
				break;
			case 4:main();
		}
	}
}
