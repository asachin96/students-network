#include<stdio.h>
#include<stdlib.h>
struct node{
	int info;
	struct node *left,*right;
};
typedef struct node *NODEPTR;
NODEPTR getnode(){
	NODEPTR p;
	p=(NODEPTR)malloc(sizeof(struct node));
	return p;
}
NODEPTR insert(NODEPTR root,int item){
	NODEPTR cur,prev,temp;
	temp=getnode();
	temp->info=item;
	temp->left=temp->right='\0';
	if(root=='\0'){
		root=temp;
		return root;
	}
	cur=root;
	while(cur!='\0'){
		prev=cur;
		if(item<cur->info)
			cur=cur->left;
		else
			cur=cur->right;
	}
	if(item==prev->info)
		printf("%d is a duplicate\n",item);
	else if(item<prev->info)
		prev->left=temp;
	else
		prev->right=temp;
	return root;
}
	
NODEPTR inorder(NODEPTR root){
	if(root!='\0'){
		inorder (root->left);
		printf("%d\n",root->info);
		inorder(root->right);
	}
}
NODEPTR preorder(NODEPTR root){
	if(root!='\0'){
		printf("%d\n",root->info);
		preorder(root->left);
		preorder(root->right);
	}
}
NODEPTR postorder(NODEPTR root){
	if(root!='\0'){
		postorder(root->left);
		postorder(root->right);
		printf("%d\n",root->info);
	}
}

main(){
	NODEPTR root='\0';
	int item,op;
	printf("Enter the elements of Binary search tree\n"); 
	while(1){
		scanf("%d",&item);
		if(item==-1)break;
		root=insert(root,item);
	}
	printf("Enter the choice of traversing tree\n1:Inorder Traversal\t2:Preorder\t3:Postorder\n"); 
	scanf("%d",&op);
	switch(op){
		case 1: inorder(root);break;
		case 2: preorder(root);break;
		case 3: postorder(root);break;
	}
}

