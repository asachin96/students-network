#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
/* validate- cheks if number of operands is one more then number of operators or not if not prints invalid and exit*/
validate (char pfix[]){
	int i=0,opd=0,opt=0;
	while(pfix[i]!='\0'){
		if(isdigit(pfix[i++]))
			opd++;
		else
			opt++;
	}
	if(opt!=opd-1)
		return(0);
}
int pop(char stack[],int *top){
	if(*top==-1){
		printf("Not a valid postfix expression\n");
		exit(0);
	}
	return(stack[(*top)--]-'0');
}
/*operate- does the required operation*/
int operate(int A,int B,char opt){
	switch(opt){
	case '+':return(A+B);
	case '-':return(A-B);
	case '*':return(A*B);
	case '/':return(A/B);
	default :printf("Undefined operator used\n");
	}
} 
/* eval- when operand push it to stack else(operator) pop the top two operands do the operation and push it to stack again.. do this till completion of the expression.. and at the end top of stack has the result pop it and print(get lost now!!)*/ 
eval(char pfix[]){
	char stack[10];
//	char  result;
	int result,A,B,i=0,top=-1;
	while(pfix[i]!='\0'){
		if(isdigit(pfix[i]))
			stack[++top]=pfix[i];
		else{
			B=pop(stack,&top);
			A=pop(stack,&top);
			result=operate(A,B,pfix[i]);
			stack[++top]=result+'0';
		}
		i++;
	}
	result=pop(stack,&top);
	printf("The result of the expression is %d",result);
}
main(){
	char pfix[10];
	printf("Enter a postfix expression having unsigned operands and operators '+','-','/','*' only\n");
	scanf("%s",pfix);
	if(!validate(pfix))
		printf("Not  a valid postfix expression\n");
	else 
		eval(pfix);
}
