#include<stdio.h>
#include<stdlib.h>
struct node{
	int info;
	struct node* next;
};
typedef struct node *NPTR;
NPTR cur,prev,next,list=NULL;
NPTR getnode(){
	NPTR p=(NPTR)malloc(sizeof(struct node));
	if(p==NULL){
		printf("Not enough space\n");
		exit(0);
	}
	p->next=NULL;
	return p;
}
input(){
	int x;
	NPTR q=list;
	while(1){
		scanf("%d",&x);
		if(x==-1) break;
		NPTR p=getnode();
		p->info=x;
		q->next=p;
		q=p;
	}
}
rev_list(){
	NPTR p;
	cur=list;
	prev=NULL;
	while(cur!=NULL){
		next=cur->next;
		cur->next=prev;
		prev=cur;
		cur=next;
	}
	list=prev;
	p=list;
	printf("The reversed list is\n");
	while(p!=NULL){
		printf("%d\n",p->info);
		p=p->next;
	}	
}	
main(){
	int x;
	printf("Enter the elements of list.Enter -1 to stop giving inputs\n");
	scanf("%d",&x);
	if(x==-1) exit(0);
	list=getnode();
	list->info=x;
	input();
	rev_list();
}
	

		
