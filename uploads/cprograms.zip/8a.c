#include<stdio.h>
#include<stdlib.h>
struct node{
	int info;
	struct node *next;
};
typedef struct node *ptr;
ptr front='\0',rear='\0';
ptr getnode(){
	ptr p=(ptr)malloc(sizeof(ptr));
	if(p=='\0'){
		printf("No space\n");
		exit(0);
	}
	p->next='\0';
		return(p);

}
insert(){
	int x;
	ptr p=getnode();
	printf("Enter element\n");
	scanf("%d",&x);
	p->info=x;
	if(rear!='\0')
		rear->next=p;
	if(front=='\0')
		front=p;
	rear=p;
}
delete(){
	int x;
	if(front=='\0'){
		printf("Empty queue\n");
		return;
	}
	else{
		x=front->info;
		if(front==rear){
			front='\0';
			rear='\0';
		}else
			front=front->next;
  		printf("%d is deleted\n",x);
	}
}
display(){
	if(front=='\0'){
		printf("Empty queue\n");
		return;
	}
	ptr q;
	printf("The elements in queue are\n");
	for(q=front;q!=rear;q=q->next)
		printf("%d\n",q->info);
	printf("%d\n",q->info);
}
main(){
	int ch;
	while(1){
		printf("Enter choice of operation\t1:insert\t2:delete\t3:display\n");
		scanf("%d",&ch);
		switch(ch){
			case 1:insert();
				break;
			case 2: delete();
				break;
			case 3: display();
				break;
			case 4: exit(0);
		}
	}
}	
