#include<stdio.h>
#include<stdlib.h>
struct node{
	int info;
	struct node *next;
};
int merge();
typedef struct node *ptr;
ptr list1='\0',list2='\0';
ptr getnode(){
	ptr p=(ptr)malloc(sizeof(ptr));
	if(p==NULL){
		printf("Not enough space\n");
		exit(0);
	}
	p->next=NULL;
	return(p);
}
display(ptr s,int i){
	if(s=='\0'){
		if(i==3)
			printf("Merged list is also empty\n");
		else
			printf("list%d is empty\n",i);
	}else{
		if(i!=3)
			printf("The elements in list%d are\n",i);
		else
			printf("The merged list is \n");
	 
		for(;s!='\0';s=s->next)
			printf("%d\t",s->info);
		printf("\n");
	}
}
main(){
	int i,x;
	ptr q=getnode(),p;
	for(i=1;i<3;i++){
		printf("Enter elements of list%d in ascending order and -1 to end\n",i);
		scanf("%d",&x);
		while(x!=-1){
			if(i==1&&list1=='\0'){
				list1=getnode();
				list1->info=x;
				q=list1;
			}else if(i==2&&list2=='\0'){ 
				list2=getnode();
				list2->info=x;
				q=list2;
			}else{
				p=getnode();
				p->info=x;
				q->next=p;
				q=p;
			}
			scanf("%d",&x);
		}
	}
	display(list1,1);
	display(list2,2);
	merge();
}
merge(){
	ptr temp,cur,prev='\0';
	if(list1=='\0')
		display(list2,3);
	else if(list2=='\0')
		display(list1,3);
	else{
		if(list1->info>list2->info){
			temp=list1;
			list1=list2;
			list2=temp;
		}
		while(list2!='\0'){
			temp=list2;
			list2=list2->next;
			for(cur=list1;cur!='\0'&&cur->info<=temp->info;cur=cur->next)
				prev=cur;
			if(prev->info==temp->info)
				continue;
			temp->next=prev->next;
			prev->next=temp;
		}
		display(list1,3);
	}
}


