#include<stdio.h>
#include<stdlib.h>
struct node {
	int info;
	struct node *left,*right;
};
typedef struct node *NODEPTR;

NODEPTR insert(int a,NODEPTR temp){
	if(temp==NULL){
		temp=(NODEPTR)malloc(sizeof(NODEPTR));
		temp->info=a;
		temp->left=temp->right=NULL;
	}else{
		if(a<temp->info)
			temp->left=insert(a,temp->left);
		else if(a>temp->info)
			temp->right=insert(a,temp->right);
	}
	return temp;
}
NODEPTR findmin(NODEPTR q){
	if(q==NULL||q->left==NULL)
		return q;
	findmin(q->left);
}
NODEPTR delete(int a,NODEPTR temp){
	NODEPTR q;
	if(temp==NULL)
		printf("\nEmpty Tree");
	else{
		if(a<temp->info)
			temp->left=delete(a,temp->left);
		else if(a>(temp->info))
			temp->right=delete(a,temp->right);
		else{
			if(temp->left&&temp->right){
				q=findmin(temp->right);
				temp->info=q->info;
				temp->info=delete(temp->info,temp->right);
			}else if(temp->left=='\0')
				temp=temp->right;
			else
				temp=temp->left;
		}
	}return temp;
}
void display(NODEPTR root){
	if(root!='\0'){
		display (root->left);
		printf("%d\n",root->info);
		display(root->right);
	}
/*	int i;
	if(temp){
		display(temp->right,level+1);
		printf("\n");
		for(i=0;i<level;i++)
			printf("");
		printf("%d",temp->info);
		display(temp->left,level+1);
	}*/
}
void main(){
	NODEPTR root='\0';
	int a,op;
	while(1){
	printf("Binary search tree\n1:Insert\t2:Delete\t3:Display\t");
	scanf("%d",&op);
	switch(op){
		case 1:
			printf("\nEnter an element:\n");
			scanf("%d",&a);
			root=insert(a,root);
			break;
		case 2:
			printf("\nEnter an element to delete\n");
			scanf("%d",&a);
			root=delete(a,root);
			break;
		case 3:if(root==NULL)
				printf("Empty tree\n");
			else 
				display(root);
			break;
	}
	}
}  			

				
