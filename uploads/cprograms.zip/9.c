#include<stdio.h>
#include<stdlib.h>
struct node{
	int info;
	struct node *left,*right;
};
typedef struct node *ptr;
ptr list=NULL;
ptr getnode(){
	ptr p=(ptr)malloc(sizeof(struct node));
	if(p==NULL){
		printf("Not Enough space\n");
		exit(0);
	}
	return p;
}
ist_front(){
	ptr p=NULL;
	if(list==NULL){
		list=getnode();
		printf("Enter element\n");
		scanf("%d",&list->info);
		list->right=list->left=NULL;
	}
	else{
		p=getnode();
		printf("Enter element\n");
		scanf("%d",&p->info);
		p->right=list;
		list->left=p;
		p->left=NULL;
		list=p;
	}
}
ist_aftern(){
	int n,i;
	ptr p=NULL,q=NULL; 
	p=getnode();
	printf("Enter after n position?\n");
	scanf("%d",&n);
	if(n==0){
		printf("No such position\n");
		return;
	}
	q=list;
	for(i=1;i<n;i++){
		if(q==NULL){
			printf("No such position\n");
			return;
		}
		q=q->right;
	}
	printf("Enter element to be inserted\n");
	scanf("%d",&p->info);	
	p->right=q->right;
	if(q->right!=NULL)
		(q->right)->left=p;
	p->left=q;
	q->right=p;
}
ist_afterky(){
	int i,key;
	ptr p='\0',q=list;
	p=getnode();
	printf("Enter key?\n");
	scanf("%d",&key);
	for(i=1;q!=NULL;i++){
		if(q->info==key){
			p=getnode();
			printf("Enter element to insert after %d\n",key);
			scanf("%d",&p->info);
			p->right=q->right;
			if(q->right!=NULL)
				(q->right)->left=p;
			p->left=q;
			q->right=p;
			return;
		}
		q=q->right;
	}
	printf("Key not found\n");
	return;
}
del_key(){
	int key;
	ptr r=list;
	printf("Enter key to be deleted?\n");
	scanf("%d",&key);
	for(r=list;r!=NULL;){
		if(r->info==key){
			ptr q=r;
			if(q->left!='\0')
			(q->left)->right=q->right;
			else 
				list=q->right;
			if(q->right!='\0')
			(q->right)->left=q->left;
			r=q->right;
			free(q);
			continue;
		}r=r->right;
	}
}
display(){
	ptr r;
	printf("The elements in list are\n");
	for(r=list;r!=NULL;r=r->right)
		printf("%d\t",r->info);
	printf("\n");
}
		
void main(){
	int op;
	while(1){
		printf("Enter operation to perform\n1:Insert at front\t2:Insert after nth element\t3:Insert to the right of a key\t4:Delete key\t5:Display list\n");
		scanf("%d",&op);
		switch(op){
			case 1:ist_front();
				break;
			case 2:ist_aftern();
				break;
			case 3:ist_afterky();
				break;
			case 4:del_key();
				break;
			case 5:display();
				break;
			case 6:exit(0);
		}
	}
}
