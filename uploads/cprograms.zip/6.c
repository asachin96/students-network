#include<stdio.h>
#include<stdlib.h>
struct node{
	char name[15];
	int id;
	int sem;
	struct node *next;
};
typedef struct node *PTR;
PTR list=NULL;
PTR getnode(){
	PTR p=(PTR)malloc(sizeof(struct node));
	if(p==NULL){
		printf("NO space\n");
		exit(0);
	}
	p->next=NULL;
	return p;
}
void insert(){
	int op,i,n;
	PTR p=getnode();
	printf("Enter student details in format Name\tid\tsem\n");
	scanf("%s\t%d\t%d",p->name,&p->id,&p->sem);
	//printf("%s",p->name);
	printf("Enter 1:To insert at front\t2:after n position\n");
	scanf("%d",&op);
	switch(op){
		case 1:if(list==NULL)
				list=p;
			else{
				p->next=list;
				list=p;
			}
			break;
		case 2:printf("Enter this after n position?\n");
			scanf("%d",&n);		
			PTR q=list;
			for(i=1;i<n;i++){
				if(q==NULL){
					printf("No such position,Cannot insert\n");
					return;
				}q=q->next;
			}
			p->next=q->next;
			q->next=p;
			break;
	}
}
void delete(int flag){
	int d;
	PTR p,q=NULL;
	printf("Give id?\n");
	scanf("%d",&d);
	for(p=list;p!=NULL;p=p->next){
		if(p->id==d){
			if(flag==1){
					printf("Student details base on id given is \nName:%s\nid:%d\t:sem:%d\nEnter updated info in same form\n",p->name,p->id,p->sem);
					scanf("%s\t%d\t%d",p->name,&p->id,&p->sem);
					return;
			}
			else{
				if(p==list)
					list=list->next;
				else
					q->next=p->next;
				free(p);
				return;
			}
		}q=p;
	}printf("student with this id not there\n");
}		
void display(){
	PTR p=list;
	printf("Student details are\nName\tid\tsem\n");
	while(p!=NULL){
		printf("%s\t%d\t%d\n",p->name,p->id,p->sem);
		p=p->next;
	}
}
void main(){
	int op;
while(1){
	printf("Enter operation you want to perform?1:insert\t2:disp\t3:delete\t4:update\t");
	scanf("%d",&op);
	switch(op){
		case 1:insert(); break;
		case 2: display(); break;
		case 3: delete(0);break;
		case 4: delete(1); break;
	}
}
}
