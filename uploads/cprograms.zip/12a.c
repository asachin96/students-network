#define SIZE 50

#include<stdio.h>
int main()
{
	char A[SIZE][SIZE], Temp[SIZE]; 
    int N, i, j;
	printf("\n\n\t ENTER THE NUMBER OF TERMS...: ");
	scanf("%d", &N);
	printf("\n\t ENTER THE ELEMENTS OF THE ARRAY...:");
	for(i=0; i<N; i++)
	{
		scanf("\n\t\t%s", &A[i]);
	}
	for(i=1; i<N; i++)
	{
		strcpy(Temp,A[i]);
		j = i-1;
		while(strcmp(Temp,A[j])<0 && j>=0)
		{
			strcpy(A[j+1],A[j]);
			j = j-1;
		}
		strcpy(A[j+1],Temp);
	}
	printf("\n\t THE ASCENDING ORDER LIST IS...:\n");
	for(i=0; i<N; i++)
		printf("\n\t\t\t%s", A[i]);
	getch();
}
