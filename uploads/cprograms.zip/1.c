#include<stdio.h>
#include<stdlib.h>
struct std{
	char name[20];
	int marks[5];
	int rank;
}student[10],temp;
void input(int *num){
	int i,j,sum;
	int **n=&num;
	printf("Enter name of students and their marks in 4 subjects\n");
	for(i=0;i<**n;i++){
		sum=0;
		scanf("%s",student[i].name);
	//	printf("%s\n",student[i].name);
		for(j=0;j<4;j++){
			scanf("%d",&(student[i].marks[j]));
			sum=sum+student[i].marks[j];
		}student[i].marks[j]=sum;
	}
}
void rank_sort(int *num){
	int **n=&num,i,y;
	student[0].rank=1;
	for(i=1;i<**n;i++){
		y=student[i].marks[4];
		int j=i;
		if(y>student[j-1].marks[4]){
			while(j>0){
				if(y>student[j-1].marks[4]){
					student[j].rank=student[j-1].rank;
					student[j-1].rank=student[j-1].rank+1;
					temp=student[j-1];
					student[j-1]=student[j];
					student[j]=temp;
					j--;
				}else if(y==student[j-1].marks[4]){
					student[j].rank=student[j-1].rank;
					break;
				}
			}
		}else if(y==student[i-1].marks[4]){
			student[i].rank=student[i-1].rank;
			continue;
		}else 
			student[i].rank=student[i-1].rank+1;			
	}// end for
}
void display(int *num){
	int i,**n=&num;
	printf("The Students mark list is as follows\n");
	printf("Name\tTotal\tRank\n");
	for(i=0;i<**n;i++){
		printf("%s\t",student[i].name);
		printf("%d\t",student[i].marks[4]);
		printf("%d\n",student[i].rank);
	}
}
//void ouput()
 void main(){
	int n;
	void (*f_ptr1)();
	f_ptr1=&input;
	printf("Enter the number of students?\n");
	scanf("%d",&n);
	if(n>10){
		printf("Not enough space for more then 10 students\n");
	}else{
		f_ptr1(&n);
		rank_sort(&n);
		display(&n);
	}
}
