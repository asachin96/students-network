#include<stdio.h>
#include<stdlib.h>
struct node{
	int info;
	struct node *next;
};
typedef struct node *ptr;
ptr list='\0';
ptr getnode(){
	ptr p=(ptr)malloc(sizeof(ptr));
	if(p=='\0'){
		printf("No space\n");
		exit(0);
	}
	p->next=NULL;
	return(p);
}
push(){
	int x;
	ptr p=getnode();
	printf("Enter element\n");
	scanf("%d",&x);
	p->info=x;
	if(list!='\0')
		p->next=list;
	list=p;
}
pop(){
	int x;
	ptr q;
	if(list=='\0'){
		printf("Stack empty\n");
		return;
	}
	x=list->info;
	q=list;
	list=list->next;
	free(q);
	printf("%d is poped\n",x);
}
display(){
	if(list=='\0'){
		printf("Stack empty\n");
		return;
	}
	ptr q;
	printf("The elements in list are\n");
	for(q=list;q!='\0';q=q->next)
		printf("%d\n",q->info);
}	
main(){
	int op;
	while(1){
		printf("Enter operation to perform 1:push\t2:pop\t3:display\n");
		scanf("%d",&op);
		switch(op){
			case 1: push();
				break;
			case 2: pop();
				break;
			case 3: display();
				break;
			case 4: exit(0);
		}
	}
}
	


